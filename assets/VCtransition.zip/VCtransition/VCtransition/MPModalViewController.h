//
//  MPModalViewController.h
//  VCtransition
//
//  Created by Alex Manzella on 29/09/14.
//  Copyright (c) 2014 mpow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPModalViewController : UIViewController{
    UIPanGestureRecognizer *pan;
}

@end
