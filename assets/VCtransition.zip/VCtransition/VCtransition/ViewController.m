//
//  ViewController.m
//  VCtransition
//
//  Created by Alex Manzella on 28/09/14.
//  Copyright (c) 2014 mpow. All rights reserved.
//

#import "ViewController.h"
#import "MPModalViewController.h"
#import "MPTransition.h"

@interface ViewController (){
    MPTransition *transitionManager;
}

@end

@implementation ViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        transitionManager=[[MPTransition alloc] init];
        self.transitioningDelegate=transitionManager;
        
    }
    return self;
}

- (IBAction)presentModal:(id)sender{
    MPModalViewController* modal=[[MPModalViewController alloc] init];
    [self presentViewController:modal animated:YES completion:nil];
}



@end
