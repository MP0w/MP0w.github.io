//
//  ViewController.h
//  VCtransition
//
//  Created by Alex Manzella on 28/09/14.
//  Copyright (c) 2014 mpow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)presentModal:(id)sender;

@end

