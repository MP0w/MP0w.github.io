//
//  MPModalViewController.m
//  VCtransition
//
//  Created by Alex Manzella on 29/09/14.
//  Copyright (c) 2014 mpow. All rights reserved.
//

#import "MPModalViewController.h"
#import "MPTransition.h"

@interface MPModalViewController (){
    MPTransition *transitionManager;
}

@end

@implementation MPModalViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        transitionManager=[[MPTransition alloc] init];
        self.transitioningDelegate=transitionManager;
        
        pan=[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
        [self.view addGestureRecognizer:pan];

    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor orangeColor];
}

- (void)pan:(UIPanGestureRecognizer *)recognizer{
    
    if (recognizer.state==UIGestureRecognizerStateBegan){
        [self dismissViewControllerAnimated:YES completion:NULL];
        [recognizer setTranslation:CGPointZero inView:self.view.superview];
        [transitionManager updateInteractiveTransition:0];
        return;
    }
    
    CGFloat percentage = [recognizer translationInView:self.view.superview].y/self.view.superview.bounds.size.height;
    
    [transitionManager updateInteractiveTransition:percentage];
    
    if (recognizer.state==UIGestureRecognizerStateEnded) {
        
        CGFloat velocityY = [recognizer velocityInView:recognizer.view.superview].y;
        BOOL cancel=(velocityY<0) || (velocityY==0 && recognizer.view.frame.origin.y<self.view.superview.bounds.size.height/2);
        CGFloat points = cancel ? recognizer.view.frame.origin.y : self.view.superview.bounds.size.height-recognizer.view.frame.origin.y;
        NSTimeInterval duration = points / velocityY;
        
        if (duration<.2) {
            duration=.2;
        }else if(duration>.6){
            duration=.6;
        }
        
        cancel ? [transitionManager cancelInteractiveTransitionWithDuration:duration] : [transitionManager finishInteractiveTransitionWithDuration:duration];
        
    }else if (recognizer.state==UIGestureRecognizerStateFailed){
        
        [transitionManager cancelInteractiveTransitionWithDuration:.35];
        
    }

}

@end
