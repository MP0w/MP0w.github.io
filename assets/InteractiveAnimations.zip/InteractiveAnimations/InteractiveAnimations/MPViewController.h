//
//  MPViewController.h
//  InteractiveAnimations
//
//  Created by Alex Manzella on 18/08/14.
//  Copyright (c) 2014 mpow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPViewController : UIViewController<UIScrollViewDelegate>

@end
