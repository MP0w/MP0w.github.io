//
//  MPViewController.m
//  InteractiveAnimations
//
//  Created by Alex Manzella on 18/08/14.
//  Copyright (c) 2014 mpow. All rights reserved.
//

#import "MPViewController.h"
#define IMAGE_HEIGHT 200

@interface MPViewController (){
    
    UIImageView *imageView;
    UIScrollView *theScrollView;
    UILabel *label;
}

@end

@implementation MPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    theScrollView=[[UIScrollView alloc] initWithFrame:self.view.bounds];
    theScrollView.delegate=self;
    theScrollView.contentSize=CGSizeMake(theScrollView.bounds.size.width, 1000); // just to make it scroll
    [self.view addSubview:theScrollView];
    
    imageView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, theScrollView.bounds.size.width, IMAGE_HEIGHT)];
    imageView.image=[UIImage imageNamed:@"image"];
    imageView.contentMode=UIViewContentModeScaleAspectFill;
    imageView.clipsToBounds=YES;
    [theScrollView addSubview:imageView];
    
    label=[[UILabel alloc] initWithFrame:imageView.bounds];
    label.font=[UIFont fontWithName:@"HelveticaNeue-ultralight" size:80];
    label.textAlignment=NSTextAlignmentCenter;
    label.textColor=[UIColor whiteColor];
    label.text=@"Parallax";
    [theScrollView addSubview:label];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat offset=scrollView.contentOffset.y;
    CGFloat percentage=offset/IMAGE_HEIGHT;
    CGFloat value=IMAGE_HEIGHT*percentage; // negative when scrolling up more than the top
    // driven animation
    NSLog(@"percentage %f %f",percentage,value);

    imageView.frame=CGRectMake(0, value, scrollView.bounds.size.width, IMAGE_HEIGHT-value);
    // if scrolling down after the top
    // y become negative
    // height = original heigh minus a negative value, so: bigger
    
    // PS: you should do anything when the image is not visible anymore but that's just a test
    CGFloat alphaValue=1-fabs(percentage);
    label.alpha=alphaValue*alphaValue*alphaValue;
    label.frame=imageView.frame;
}

@end
